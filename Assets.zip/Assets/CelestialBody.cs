using System.Collections.Generic;
using UnityEngine;
public class CelestialBody : MonoBehaviour
{
    public static float   G = 6.67408f * Mathf.Pow(10, -3) * 2;
    internal        float   mass;
    public        float surfaceGravity;
    public        float   radius;
    public        Vector3 velocity = Vector3.zero;
    public        Vector3 initialVelocity = Vector3.zero;
    public        Color   color;
    public       bool    isSun = false;
    private void Start()
    {
        transform.localScale = new(radius, radius, radius);
        velocity = initialVelocity;
        // Calculate mass from surface gravity and radius
        mass = surfaceGravity * radius * radius / G;
        GetComponent<Renderer>().material.color = color;
    }
    private void ApplyVelocity(IEnumerable<CelestialBody> _bodies, out Vector3 _newVelocity)
    {
        _newVelocity = velocity;
        foreach (CelestialBody _body in _bodies)
        {
            if (_body == this || _body == null)
                continue;
            
            Vector3 _direction = _body.transform.position - transform.position;
            float   _sqrdistance  = _direction.sqrMagnitude;
            float   _force     = G * mass * _body.mass / _sqrdistance;
            _newVelocity += _direction.normalized      * _force / mass * Time.deltaTime;
        }
    }
    internal void ApplyVelocity(IEnumerable<CelestialBody> _bodies)
    {
        if (isSun)
            return;
        
        ApplyVelocity(_bodies, out Vector3 _newVelocity);
        velocity = _newVelocity;
    }
    private void OnDrawGizmos()
    {
        // change size 
        transform.localScale = new(radius, radius, radius);
        // change mass
        mass = surfaceGravity * radius * radius / G;
    }
}
