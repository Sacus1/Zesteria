using System.Diagnostics.CodeAnalysis;
using UnityEngine;
using UnityEngine.InputSystem;
[SuppressMessage("ReSharper", "UnusedMember.Global")]
public sealed class PlayerMovement : MonoBehaviour
{
	public  float     speed            = 5f;
	public  float     jumpForce        = 5f;
	public  float     mouseSensitivity = .5f;
	private Rigidbody rb;
	private Vector3   moveDirection;
	private Collider  col;
	private void Start()
	{
		// lock cursor
		Cursor.lockState = CursorLockMode.Locked;
		col              = GetComponent<Collider>();
		rb               = GetComponent<Rigidbody>();
	}
	// Update is called once per frame
	private void Update()
	{
		Vector3    _strongestGravitationalPull       = Vector3.zero;
		Transform _strongestGravitationalPullObject = null;
		foreach (CelestialBody _body in GameManager.instance.bodies)
		{
			if (_body == null) continue;

			Vector3 _direction = _body.transform.position - transform.position;
			float   _sqrDst    = _direction.sqrMagnitude;
			float   _force     = CelestialBody.G * _body.mass / _sqrDst;
			Vector3 _gravity   = _direction.normalized        * _force;
			if (_gravity.sqrMagnitude > _strongestGravitationalPull.sqrMagnitude)
			{
				_strongestGravitationalPull       = _gravity;
				_strongestGravitationalPullObject = _body.transform;
			}
		}
		rb.AddForce(_strongestGravitationalPull, ForceMode.Acceleration);
		// look if we are between 1.5 and 3 time the radious of the strongest gravity source
		if (_strongestGravitationalPullObject != null)
		{
			float _distance = (_strongestGravitationalPullObject.position - transform.position).magnitude;
			if (_distance > 1.5f * _strongestGravitationalPullObject.localScale.x && _distance < 3f * _strongestGravitationalPullObject.localScale.x)
			{
				transform.SetParent(_strongestGravitationalPullObject);
			}
			// if we are 3x the radius of the strongest gravity source
			if (_distance > _strongestGravitationalPullObject.localScale.x * 3f)
			{
				transform.SetParent(null, true);
			}
		}
		// Rotate to align with gravity up
		rb.rotation = Quaternion.FromToRotation(transform.up, -_strongestGravitationalPull.normalized) * rb.rotation;
		// Move
		transform.Translate(transform.TransformDirection(moveDirection) * (speed * Time.deltaTime), Space.World);
	}
	public void OnMove(InputValue _value)
	{
		Vector3 _input = _value.Get<Vector2>();
		moveDirection = new(_input.x, 0, _input.y);
	}
	public void OnJump()
	{
		rb.AddForce(transform.up * jumpForce, ForceMode.Impulse);
	}
	public void OnLook(InputValue _value)
	{
		Vector2 _input = _value.Get<Vector2>();
		transform.Rotate(Vector3.up, _input.x * mouseSensitivity);
	}
}