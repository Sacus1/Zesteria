﻿using UnityEngine;
public class GameManager : MonoBehaviour
{
	public CelestialBody[] bodies;
	public static GameManager instance;
	public int simulatedSteps = 100;
	public GameObject sun;
	private void Awake()
	{
		instance = this;
	}
	private void Update()
	{
		foreach (CelestialBody _body in bodies)
		{
			_body.ApplyVelocity(bodies);
			if (_body.isSun)
			{
				sun = _body.gameObject;
			}
		}
		// update position
		foreach (CelestialBody _body in bodies)
			_body.transform.position += _body.velocity * Time.deltaTime;
	}
	private void OnDrawGizmos()
	{
		// if in play mode draw a giant line to show velocity direction of each body
		if (Application.isPlaying)
		{
			foreach (CelestialBody _body in bodies)
			{
				Gizmos.DrawLine(_body.transform.position, _body.transform.position + _body.velocity * 100);
				// draw a sphere in wireframe at 3x the radius of the body to show the orbit
				Gizmos.DrawWireSphere(_body.transform.position, _body.radius * 3);
			}
			return;
		}
		// simulate gravity
		// copy bodies properties
		Vector3[] _positions = new Vector3[bodies.Length];
		Vector3[] _velocities = new Vector3[bodies.Length];
		for (int i = 0; i < bodies.Length; i++)
		{
			if (bodies[i] == null)
				continue;
			_positions[i] = bodies[i].transform.position;
			_velocities[i] = bodies[i].initialVelocity;
		}
		// simulate
		for (int i = 0; i < simulatedSteps; i++)
		{
			for (int j = 0; j < bodies.Length; j++)
			{
				if (bodies[j] == null || bodies[j].isSun)
					continue;
				for (int k = 0; k < bodies.Length; k++)
				{
					if (j == k)
						continue;
					Vector3 _direction = _positions[k] - _positions[j];
					float _sqrDistance = _direction.sqrMagnitude;
					float _force = CelestialBody.G * bodies[j].mass * bodies[k].mass / _sqrDistance;
					_velocities[j] += _direction.normalized * _force / bodies[j].mass * Time.deltaTime;
				}
			}
			// update position
			for (int j = 0; j < bodies.Length; j++)
			{
				_positions[j] += _velocities[j] * Time.deltaTime;
				Gizmos.DrawLine(_positions[j], _positions[j] + _velocities[j] * Time.deltaTime);
			}
		}
	}
}